
import React, { useState, useEffect, useMemo } from 'react';
import { AppState, Movie } from './types';
import { getAppState, saveAppState } from './store';
import Navbar from './components/Navbar';
import HeroCarousel from './components/HeroCarousel';
import MovieRow from './components/MovieRow';
import MovieModal from './components/MovieModal';
import AdminPanel from './components/AdminPanel';
import PasskeyModal from './components/PasskeyModal';
import Footer from './components/Footer';
import { ADMIN_PASSKEY } from './constants';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>(getAppState());
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isPasskeyModalOpen, setIsPasskeyModalOpen] = useState(false);
  const [passkeyError, setPasskeyError] = useState<string | null>(null);
  const [isScrolled, setIsScrolled] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  useEffect(() => {
    saveAppState(state);
  }, [state]);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Check for admin access via hash
  useEffect(() => {
    const checkAdmin = () => {
      const hash = window.location.hash;
      if (hash.includes(`admin-key=${ADMIN_PASSKEY}`)) {
        setIsAdminOpen(true);
        // Clean up URL without reload
        window.history.replaceState(null, '', window.location.pathname);
      }
    };
    checkAdmin();
    window.addEventListener('hashchange', checkAdmin);
    return () => window.removeEventListener('hashchange', checkAdmin);
  }, []);

  const handlePasskeySubmit = (passkey: string) => {
    if (passkey === ADMIN_PASSKEY) {
      setIsAdminOpen(true);
      setIsPasskeyModalOpen(false);
      setPasskeyError(null);
    } else {
      setPasskeyError('Invalid authentication key. Please try again.');
    }
  };

  const today = useMemo(() => new Date().toISOString().split('T')[0], []);

  const categorizedMovies = useMemo(() => {
    const movies = state.movies;
    const comingSoon = movies.filter(m => m.releaseDate > today);
    const released = movies.filter(m => m.releaseDate <= today);
    
    // Last 30 days are "New Releases"
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    const thirtyDaysAgoStr = thirtyDaysAgo.toISOString().split('T')[0];
    
    const newReleases = released.filter(m => m.releaseDate >= thirtyDaysAgoStr);

    return {
      comingSoon,
      newReleases,
      allReleased: released,
      recommended: movies.filter(m => m.isRecommended).slice(0, 5)
    };
  }, [state.movies, today]);

  const updateState = (newState: AppState) => setState(newState);

  return (
    <div className="min-h-screen bg-dark text-white font-sans selection:bg-gold-500 selection:text-dark flex flex-col">
      <Navbar 
        isScrolled={isScrolled} 
        onAdminClick={() => setIsPasskeyModalOpen(true)}
        onCategorySelect={setActiveCategory}
        activeCategory={activeCategory}
      />

      <main className="flex-grow">
        {!activeCategory ? (
          <>
            <HeroCarousel 
              movies={categorizedMovies.recommended} 
              onMovieClick={setSelectedMovie} 
            />

            <div className="-mt-12 sm:-mt-16 relative z-10 space-y-2">
              <MovieRow 
                title="New Releases" 
                movies={categorizedMovies.newReleases} 
                onMovieClick={setSelectedMovie} 
              />
              
              <MovieRow 
                title="Coming Soon" 
                movies={categorizedMovies.comingSoon} 
                onMovieClick={setSelectedMovie} 
              />

              {state.genres.map(genre => (
                <MovieRow 
                  key={genre}
                  title={genre} 
                  movies={categorizedMovies.allReleased.filter(m => m.genres.includes(genre))} 
                  onMovieClick={setSelectedMovie} 
                />
              ))}
            </div>
          </>
        ) : (
          <div className="pt-32 px-8 sm:px-12 space-y-8 min-h-[60vh]">
            <h1 className="text-4xl font-serif font-bold text-gold-500">{activeCategory}</h1>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {categorizedMovies.allReleased
                .filter(m => activeCategory === 'Browse' || m.genres.includes(activeCategory))
                .map(movie => (
                  <div key={movie.id} onClick={() => setSelectedMovie(movie)} className="cursor-pointer group">
                    <div className="aspect-[16/9] overflow-hidden rounded-md border border-gray-800 transition-all group-hover:border-gold-500 group-hover:scale-105">
                      <img src={movie.posterUrl} className="w-full h-full object-cover" />
                    </div>
                    <p className="mt-2 font-bold group-hover:text-gold-500 transition-colors">{movie.title}</p>
                  </div>
                ))}
            </div>
          </div>
        )}
      </main>

      <Footer />

      <MovieModal 
        movie={selectedMovie} 
        onClose={() => setSelectedMovie(null)} 
      />

      <PasskeyModal 
        isOpen={isPasskeyModalOpen} 
        onClose={() => { setIsPasskeyModalOpen(false); setPasskeyError(null); }}
        onSubmit={handlePasskeySubmit}
        error={passkeyError}
      />

      {isAdminOpen && (
        <AdminPanel 
          state={state} 
          updateState={updateState} 
          onClose={() => setIsAdminOpen(false)} 
        />
      )}
    </div>
  );
};

export default App;
