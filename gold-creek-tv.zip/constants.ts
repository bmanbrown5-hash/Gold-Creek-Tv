
import { Movie } from './types';

export const ADMIN_PASSKEY = 'goldcreektv2024';

export const INITIAL_GENRES = [
  'Action', 'Drama', 'Comedy', 'Sci-Fi', 'Thriller', 'Horror', 'Documentary'
];

export const INITIAL_MOVIES: Movie[] = [
  {
    id: '1',
    title: 'The Gilded Age',
    description: 'A cinematic journey through the rise of an empire, where gold is the only currency that matters and loyalty is bought with blood.',
    posterUrl: 'https://picsum.photos/seed/gold1/800/1200',
    trailerUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    ageRating: '16+',
    length: '2h 15m',
    contentType: 'feature',
    releaseDate: '2023-12-01',
    genres: ['Drama', 'Action'],
    isRecommended: true
  },
  {
    id: '2',
    title: 'Mountain Echoes',
    description: 'Deep in the heart of Gold Creek, secrets whispered in the wind become reality. A thriller that will leave you breathless.',
    posterUrl: 'https://picsum.photos/seed/gold2/800/1200',
    trailerUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    ageRating: '13+',
    length: '1h 45m',
    contentType: 'short',
    releaseDate: '2024-05-15',
    genres: ['Thriller'],
    isRecommended: true
  },
  {
    id: '3',
    title: 'Solaris Drift',
    description: 'When the sun fails, humanity looks to the stars. A sci-fi epic about the last voyage of the Golden Ark.',
    posterUrl: 'https://picsum.photos/seed/gold3/800/1200',
    trailerUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    ageRating: 'PG-13',
    length: '2h 30m',
    contentType: 'feature',
    releaseDate: '2024-11-20',
    genres: ['Sci-Fi', 'Action'],
    isRecommended: true
  },
  {
    id: '4',
    title: 'Legacy of the Creek',
    description: 'Documenting a century of mysteries surrounding the mysterious waters of Gold Creek.',
    posterUrl: 'https://picsum.photos/seed/gold4/800/1200',
    trailerUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    ageRating: 'G',
    length: '1h 10m',
    contentType: 'documentary',
    releaseDate: '2025-01-01',
    genres: ['Documentary'],
    isRecommended: false
  },
  {
    id: '5',
    title: 'Nightshade',
    description: 'A comedy of errors set in a luxury estate where nothing is as it seems and everyone wants a piece of the pie.',
    posterUrl: 'https://picsum.photos/seed/gold5/800/1200',
    trailerUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    ageRating: '18+',
    length: '1h 55m',
    contentType: 'feature',
    releaseDate: '2024-03-10',
    genres: ['Comedy'],
    isRecommended: true
  }
];
