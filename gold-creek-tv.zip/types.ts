
export type ContentType = 'feature' | 'short' | 'documentary';

export interface Movie {
  id: string;
  title: string;
  description: string;
  posterUrl: string;
  trailerUrl: string;
  videoUrl: string;
  ageRating: string;
  length: string;
  contentType: ContentType;
  releaseDate: string;
  genres: string[];
  isRecommended: boolean;
}

export interface Genre {
  id: string;
  name: string;
}

export interface AppState {
  movies: Movie[];
  genres: string[];
  recommendedIds: string[];
}
