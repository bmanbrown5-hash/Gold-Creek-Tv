
import React, { useState, useRef } from 'react';
import { Movie, AppState, ContentType } from '../types';
import { CloseIcon, PlusIcon, FolderIcon } from './Icons';

interface AdminPanelProps {
  state: AppState;
  updateState: (newState: AppState) => void;
  onClose: () => void;
}

type AdminTab = 'add' | 'manage' | 'carousel' | 'genres';

const AdminPanel: React.FC<AdminPanelProps> = ({ state, updateState, onClose }) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('add');
  const [editingMovie, setEditingMovie] = useState<Partial<Movie>>({ 
    genres: [], 
    contentType: 'feature', 
    releaseDate: new Date().toISOString().split('T')[0] 
  });
  const [newGenreName, setNewGenreName] = useState('');

  const posterInputRef = useRef<HTMLInputElement>(null);
  const trailerInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const handleSaveMovie = (e: React.FormEvent) => {
    e.preventDefault();
    const movieToSave = {
      ...editingMovie,
      id: editingMovie.id || Math.random().toString(36).substr(2, 9),
      genres: editingMovie.genres || [],
    } as Movie;

    const newMovies = editingMovie.id 
      ? state.movies.map(m => m.id === movieToSave.id ? movieToSave : m)
      : [...state.movies, movieToSave];

    updateState({ ...state, movies: newMovies });
    
    // Reset form after add
    if (!editingMovie.id) {
        setEditingMovie({ 
            genres: [], 
            contentType: 'feature', 
            releaseDate: new Date().toISOString().split('T')[0] 
        });
        alert('Content added successfully!');
    } else {
        setActiveTab('manage');
        setEditingMovie({ genres: [], contentType: 'feature' });
    }
  };

  const handleDeleteMovie = (id: string) => {
    if (confirm('Are you sure you want to delete this title?')) {
      updateState({
        ...state,
        movies: state.movies.filter(m => m.id !== id)
      });
    }
  };

  const handleAddGenre = () => {
    if (newGenreName && !state.genres.includes(newGenreName)) {
      updateState({
        ...state,
        genres: [...state.genres, newGenreName]
      });
      setNewGenreName('');
    }
  };

  const toggleRecommended = (id: string) => {
    const recommendedCount = state.movies.filter(m => m.isRecommended).length;
    const isCurrentlyRecommended = state.movies.find(m => m.id === id)?.isRecommended;
    
    if (!isCurrentlyRecommended && recommendedCount >= 5) {
        alert("Maximum 5 featured titles allowed for the carousel.");
        return;
    }

    const newMovies = state.movies.map(m => m.id === id ? { ...m, isRecommended: !m.isRecommended } : m);
    updateState({ ...state, movies: newMovies });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, field: 'posterUrl' | 'trailerUrl' | 'videoUrl') => {
    const file = e.target.files?.[0];
    if (file) {
      const localUrl = URL.createObjectURL(file);
      setEditingMovie(prev => ({ ...prev, [field]: localUrl }));
    }
  };

  const NavButton = ({ tab, label }: { tab: AdminTab, label: string }) => (
    <button 
      onClick={() => {
          setActiveTab(tab);
          if (tab !== 'add') setEditingMovie({ genres: [], contentType: 'feature' });
      }}
      className={`px-4 py-2 text-sm font-bold transition-all border-b-2 ${
        activeTab === tab 
        ? 'text-gold-500 border-gold-500' 
        : 'text-gray-500 border-transparent hover:text-white'
      }`}
    >
      {label}
    </button>
  );

  return (
    <div className="fixed inset-0 z-[200] bg-dark flex flex-col pt-16 sm:pt-20 animate-in fade-in slide-in-from-bottom-4 duration-300">
      <header className="px-8 py-6 border-b border-gray-800 bg-dark-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
            <h1 className="text-2xl font-bold text-gold-500 font-serif">Gold Creek Admin</h1>
            <p className="text-xs text-gray-500 uppercase tracking-widest mt-1">Production Control Center</p>
        </div>
        
        <nav className="flex items-center gap-2 sm:gap-4 overflow-x-auto pb-2 sm:pb-0 no-scrollbar">
            <NavButton tab="add" label="Add Content" />
            <NavButton tab="manage" label="Library" />
            <NavButton tab="carousel" label="Carousel" />
            <NavButton tab="genres" label="Categories" />
        </nav>

        <button onClick={onClose} className="p-2 hover:bg-dark-200 rounded-full transition-colors self-end sm:self-center">
          <CloseIcon />
        </button>
      </header>

      <div className="flex-1 overflow-y-auto p-4 sm:p-8 w-full">
        <div className="max-w-6xl mx-auto">
            {activeTab === 'add' && (
                <form onSubmit={handleSaveMovie} className="space-y-6 bg-dark-100 p-6 sm:p-10 rounded-xl border border-gray-800 shadow-2xl animate-in zoom-in-95 duration-200">
                    <div className="flex items-center justify-between mb-4">
                        <h2 className="text-2xl font-bold text-gold-500">{editingMovie?.id ? 'Edit Title' : 'Add New Content'}</h2>
                        {editingMovie?.id && (
                            <button 
                                type="button"
                                onClick={() => setActiveTab('manage')}
                                className="text-xs text-gray-400 hover:text-white underline"
                            >
                                Cancel Edit
                            </button>
                        )}
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-tighter">Title</label>
                            <input 
                                required
                                value={editingMovie?.title || ''}
                                onChange={e => setEditingMovie(prev => ({ ...prev, title: e.target.value }))}
                                className="w-full bg-dark-200 border border-gray-700 rounded px-4 py-2 focus:border-gold-500 outline-none text-white placeholder:text-gray-600"
                                placeholder="Enter movie title"
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-tighter">Release Date</label>
                            <input 
                                type="date"
                                required
                                value={editingMovie?.releaseDate || ''}
                                onChange={e => setEditingMovie(prev => ({ ...prev, releaseDate: e.target.value }))}
                                className="w-full bg-dark-200 border border-gray-700 rounded px-4 py-2 focus:border-gold-500 outline-none text-white"
                            />
                        </div>
                    </div>

                    <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-tighter">Description</label>
                        <textarea 
                            required
                            rows={3}
                            value={editingMovie?.description || ''}
                            onChange={e => setEditingMovie(prev => ({ ...prev, description: e.target.value }))}
                            className="w-full bg-dark-200 border border-gray-700 rounded px-4 py-2 focus:border-gold-500 outline-none text-white resize-none"
                            placeholder="Brief synopsis..."
                        />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-tighter">Content Type</label>
                            <select 
                                value={editingMovie?.contentType || 'feature'}
                                onChange={e => setEditingMovie(prev => ({ ...prev, contentType: e.target.value as ContentType }))}
                                className="w-full bg-dark-200 border border-gray-700 rounded px-4 py-2 focus:border-gold-500 outline-none text-white appearance-none"
                            >
                                <option value="feature">Feature Film</option>
                                <option value="short">Short Film</option>
                                <option value="documentary">Documentary</option>
                            </select>
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-tighter">Maturity Rating</label>
                            <input 
                                value={editingMovie?.ageRating || ''}
                                onChange={e => setEditingMovie(prev => ({ ...prev, ageRating: e.target.value }))}
                                placeholder="e.g. TV-MA, 18+"
                                className="w-full bg-dark-200 border border-gray-700 rounded px-4 py-2 focus:border-gold-500 outline-none"
                            />
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-tighter">Duration</label>
                            <input 
                                value={editingMovie?.length || ''}
                                onChange={e => setEditingMovie(prev => ({ ...prev, length: e.target.value }))}
                                placeholder="e.g. 1h 45m"
                                className="w-full bg-dark-200 border border-gray-700 rounded px-4 py-2 focus:border-gold-500 outline-none"
                            />
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-tighter">Poster Artwork</label>
                            <div className="flex gap-2">
                                <input type="file" hidden ref={posterInputRef} accept="image/*" onChange={e => handleFileChange(e, 'posterUrl')} />
                                <button 
                                    type="button" 
                                    onClick={() => posterInputRef.current?.click()}
                                    className="flex-1 flex items-center justify-center gap-2 bg-dark-300 border border-dashed border-gray-700 rounded p-2 text-xs text-gray-400 hover:text-gold-500 hover:border-gold-500 transition-all"
                                >
                                    <FolderIcon className="w-4 h-4" /> {editingMovie?.posterUrl ? 'Change Poster' : 'Browse Files'}
                                </button>
                            </div>
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-tighter">Trailer Clip</label>
                            <div className="flex gap-2">
                                <input type="file" hidden ref={trailerInputRef} accept="video/*" onChange={e => handleFileChange(e, 'trailerUrl')} />
                                <button 
                                    type="button" 
                                    onClick={() => trailerInputRef.current?.click()}
                                    className="flex-1 flex items-center justify-center gap-2 bg-dark-300 border border-dashed border-gray-700 rounded p-2 text-xs text-gray-400 hover:text-gold-500 hover:border-gold-500 transition-all"
                                >
                                    <FolderIcon className="w-4 h-4" /> {editingMovie?.trailerUrl ? 'Change Trailer' : 'Browse Files'}
                                </button>
                            </div>
                        </div>
                        <div className="space-y-2">
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-tighter">Master Film File</label>
                            <div className="flex gap-2">
                                <input type="file" hidden ref={videoInputRef} accept="video/*" onChange={e => handleFileChange(e, 'videoUrl')} />
                                <button 
                                    type="button" 
                                    onClick={() => videoInputRef.current?.click()}
                                    className="flex-1 flex items-center justify-center gap-2 bg-dark-300 border border-dashed border-gray-700 rounded p-2 text-xs text-gray-400 hover:text-gold-500 hover:border-gold-500 transition-all"
                                >
                                    <FolderIcon className="w-4 h-4" /> {editingMovie?.videoUrl ? 'Change Master' : 'Browse Files'}
                                </button>
                            </div>
                        </div>
                    </div>

                    <div className="space-y-2">
                        <label className="text-xs font-bold text-gray-500 uppercase tracking-tighter">Genres</label>
                        <div className="flex flex-wrap gap-2 p-4 bg-dark-200 border border-gray-700 rounded-lg">
                            {state.genres.map(g => (
                                <button
                                    key={g}
                                    type="button"
                                    onClick={() => {
                                        const current = editingMovie?.genres || [];
                                        const next = current.includes(g) ? current.filter(x => x !== g) : [...current, g];
                                        setEditingMovie(prev => ({ ...prev, genres: next }));
                                    }}
                                    className={`px-3 py-1.5 rounded-full text-[10px] font-bold tracking-wider transition-all border ${
                                        editingMovie?.genres?.includes(g) 
                                            ? 'bg-gold-500 border-gold-500 text-dark shadow-[0_0_10px_rgba(212,175,55,0.3)]' 
                                            : 'bg-dark-300 border-gray-700 text-gray-500 hover:text-white'
                                    }`}
                                >
                                    {g}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div className="flex justify-end pt-4">
                        <button 
                            type="submit"
                            className="w-full sm:w-auto bg-gold-500 text-dark px-16 py-3 rounded-lg font-bold hover:bg-gold-400 transition-all transform active:scale-95 shadow-xl"
                        >
                            {editingMovie?.id ? 'Update Production' : 'Register Content'}
                        </button>
                    </div>
                </form>
            )}

            {activeTab === 'manage' && (
                <div className="space-y-6 animate-in fade-in slide-in-from-left-4 duration-300">
                    <div className="flex items-center justify-between">
                        <h2 className="text-xl font-bold">Media Library</h2>
                        <span className="text-xs text-gray-500">{state.movies.length} Titles Registered</span>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
                        {state.movies.map(movie => (
                            <div key={movie.id} className="group relative bg-dark-100 border border-gray-800 rounded overflow-hidden hover:border-gold-500/50 transition-all flex flex-col h-[280px]">
                                <div className="h-48 overflow-hidden">
                                    <img src={movie.posterUrl} className="w-full h-full object-cover grayscale-[0.5] group-hover:grayscale-0 transition-all duration-500 group-hover:scale-105" />
                                </div>
                                <div className="p-3 flex-1 flex flex-col justify-between">
                                    <h3 className="text-xs font-bold truncate text-gray-200 group-hover:text-gold-500">{movie.title}</h3>
                                    <div className="flex items-center justify-between gap-1 mt-2">
                                        <button 
                                            onClick={() => { setEditingMovie(movie); setActiveTab('add'); }}
                                            className="p-1.5 bg-dark-200 text-gray-400 hover:text-gold-500 hover:bg-dark-300 rounded text-[10px] font-bold flex-1"
                                        >
                                            EDIT
                                        </button>
                                        <button 
                                            onClick={() => handleDeleteMovie(movie.id)}
                                            className="p-1.5 bg-dark-200 text-gray-400 hover:text-red-500 hover:bg-red-900/10 rounded text-[10px] font-bold flex-1"
                                        >
                                            DEL
                                        </button>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {activeTab === 'carousel' && (
                <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                    <div className="bg-dark-100 p-6 rounded-xl border border-gold-500/20">
                        <h2 className="text-xl font-bold text-gold-500 mb-2">Featured Carousel Management</h2>
                        <p className="text-sm text-gray-400">Select up to 5 titles to appear in the main homepage rotating carousel.</p>
                        <div className="mt-4 flex items-center gap-2">
                             <div className="flex gap-1">
                                {[1,2,3,4,5].map(i => (
                                    <div key={i} className={`h-1.5 w-6 rounded-full ${i <= state.movies.filter(m => m.isRecommended).length ? 'bg-gold-500' : 'bg-gray-800'}`} />
                                ))}
                             </div>
                             <span className="text-[10px] font-bold text-gray-500 uppercase">{state.movies.filter(m => m.isRecommended).length}/5 Slots Used</span>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                        {state.movies.map(movie => (
                            <button 
                                key={movie.id} 
                                onClick={() => toggleRecommended(movie.id)}
                                className={`relative text-left group border rounded-lg overflow-hidden transition-all ${
                                    movie.isRecommended 
                                    ? 'border-gold-500 ring-2 ring-gold-500/20' 
                                    : 'border-gray-800 hover:border-gray-600 opacity-60 hover:opacity-100'
                                }`}
                            >
                                <div className="h-32 bg-gray-900 overflow-hidden">
                                    <img src={movie.posterUrl} className="w-full h-full object-cover" />
                                </div>
                                <div className="p-3 bg-dark-100 flex items-center justify-between">
                                    <span className="text-sm font-bold truncate flex-1 pr-2">{movie.title}</span>
                                    {movie.isRecommended && <span className="text-gold-500 text-xs font-black">★</span>}
                                </div>
                            </button>
                        ))}
                    </div>
                </div>
            )}

            {activeTab === 'genres' && (
                <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-300">
                    <div className="bg-dark-100 p-8 rounded-xl border border-gray-800 space-y-6 max-w-2xl mx-auto">
                        <div className="space-y-2">
                            <h2 className="text-xl font-bold text-gold-500 uppercase tracking-widest">Library Categories</h2>
                            <p className="text-sm text-gray-400">Adding a new category will automatically generate a new content row on the homepage.</p>
                        </div>
                        
                        <div className="flex flex-wrap gap-2">
                            {state.genres.map(g => (
                                <div key={g} className="group flex items-center gap-2 px-4 py-2 bg-dark-200 border border-gray-700 rounded-full text-sm">
                                    {g}
                                    <button 
                                        onClick={() => updateState({...state, genres: state.genres.filter(x => x !== g)})}
                                        className="text-gray-500 hover:text-red-500 transition-colors"
                                    >
                                        <CloseIcon className="w-3 h-3" />
                                    </button>
                                </div>
                            ))}
                        </div>

                        <div className="flex gap-2 pt-4">
                            <input 
                                type="text" 
                                value={newGenreName}
                                onChange={(e) => setNewGenreName(e.target.value)}
                                placeholder="E.g. Thriller, Mystery..."
                                className="flex-1 bg-dark-200 border border-gray-700 rounded-lg px-4 py-2 text-sm focus:border-gold-500 outline-none"
                            />
                            <button 
                                onClick={handleAddGenre} 
                                className="bg-gold-500 text-dark px-6 py-2 rounded-lg text-sm font-bold hover:bg-gold-400 transition-all active:scale-95"
                            >
                                Create Genre
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;
