
import React, { useState, useEffect } from 'react';
import { Movie } from '../types';
import { PlayIcon, InfoIcon } from './Icons';

interface HeroCarouselProps {
  movies: Movie[];
  onMovieClick: (movie: Movie) => void;
}

const HeroCarousel: React.FC<HeroCarouselProps> = ({ movies, onMovieClick }) => {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    if (movies.length <= 1) return;
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % movies.length);
    }, 10000);
    return () => clearInterval(interval);
  }, [movies.length]);

  if (movies.length === 0) return null;

  const currentMovie = movies[activeIndex];

  return (
    <div className="relative h-[65vh] sm:h-[90vh] w-full overflow-hidden">
      {/* Background Poster */}
      <div className="absolute inset-0">
        <img 
          src={currentMovie.posterUrl} 
          alt={currentMovie.title}
          className="w-full h-full object-cover transition-opacity duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-dark/90 via-dark/40 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-dark via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative h-full flex flex-col justify-end px-8 sm:px-12 pb-32 sm:pb-40 max-w-2xl space-y-4">
        <h1 className="text-4xl sm:text-6xl font-serif font-bold text-white tracking-tight drop-shadow-lg">
          {currentMovie.title}
        </h1>
        
        <p className="text-sm sm:text-lg text-gray-200 line-clamp-3 font-medium max-w-xl drop-shadow">
          {currentMovie.description}
        </p>

        <div className="flex items-center gap-3 pt-4">
          <button 
            className="flex items-center gap-2 bg-white text-dark px-6 py-2.5 rounded hover:bg-gray-200 transition-colors font-bold text-lg"
            onClick={() => onMovieClick(currentMovie)}
          >
            <PlayIcon className="w-6 h-6" /> Play
          </button>
          <button 
            className="flex items-center gap-2 bg-gray-500/50 text-white px-6 py-2.5 rounded hover:bg-gray-500/80 transition-colors font-bold text-lg backdrop-blur-sm"
            onClick={() => onMovieClick(currentMovie)}
          >
            <InfoIcon className="w-6 h-6" /> More Info
          </button>
        </div>
      </div>

      {/* Indicators */}
      <div className="absolute bottom-16 sm:bottom-20 right-12 flex gap-2">
        {movies.map((_, idx) => (
          <button 
            key={idx}
            className={`h-1 transition-all duration-300 ${activeIndex === idx ? 'w-8 bg-gold-500' : 'w-4 bg-gray-600 hover:bg-gray-400'}`}
            onClick={() => setActiveIndex(idx)}
          />
        ))}
      </div>
    </div>
  );
};

export default HeroCarousel;
