
import React, { useState, useRef, useEffect } from 'react';
import { Movie } from '../types';
import { PlayIcon, PlusIcon, ChevronRight } from './Icons';

interface MovieCardProps {
  movie: Movie;
  onClick: (movie: Movie) => void;
}

const MovieCard: React.FC<MovieCardProps> = ({ movie, onClick }) => {
  const [isHovered, setIsHovered] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const timeoutRef = useRef<number | null>(null);

  const handleMouseEnter = () => {
    timeoutRef.current = window.setTimeout(() => {
      setIsHovered(true);
    }, 400);
  };

  const handleMouseLeave = () => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    setIsHovered(false);
  };

  useEffect(() => {
    if (isHovered && videoRef.current) {
      videoRef.current.play().catch(() => {});
    } else if (videoRef.current) {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
    }
  }, [isHovered]);

  return (
    <div 
      className="relative flex-shrink-0 w-40 sm:w-64 aspect-[16/9] transition-transform duration-300 z-10 hover:z-50 cursor-pointer"
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={() => onClick(movie)}
    >
      {/* Base Image */}
      <img 
        src={movie.posterUrl} 
        alt={movie.title}
        className={`w-full h-full object-cover rounded-md shadow-lg transition-opacity duration-300 ${isHovered ? 'opacity-0' : 'opacity-100'}`}
      />

      {/* Hover State Container */}
      <div 
        className={`absolute top-0 left-0 w-full h-full transform transition-all duration-300 bg-dark-200 rounded-md shadow-2xl overflow-hidden ${
          isHovered ? 'scale-125 opacity-100' : 'scale-100 opacity-0 pointer-events-none'
        }`}
      >
        <div className="relative w-full aspect-[16/9]">
          <video 
            ref={videoRef}
            src={movie.trailerUrl}
            muted
            loop
            playsInline
            className="w-full h-full object-cover"
          />
          <div className="absolute bottom-2 left-2 text-white font-bold text-sm drop-shadow-md">
            {movie.title}
          </div>
        </div>
        
        <div className="p-3 bg-dark-200 space-y-2">
          <div className="flex items-center gap-2">
            <button className="p-1.5 bg-white rounded-full text-dark hover:bg-gray-200 transition-colors">
              <PlayIcon className="w-4 h-4" />
            </button>
            <button className="p-1.5 border-2 border-gray-500 rounded-full text-white hover:border-white transition-colors">
              <PlusIcon className="w-4 h-4" />
            </button>
            <div className="ml-auto p-1.5 border-2 border-gray-500 rounded-full text-white hover:border-white transition-colors">
              <ChevronRight className="w-4 h-4" />
            </div>
          </div>
          
          <div className="flex flex-wrap items-center gap-2 text-[10px] sm:text-xs">
            <span className="text-green-500 font-bold">98% Match</span>
            <span className="px-1 border border-gray-400 text-gray-300 rounded-sm">{movie.ageRating}</span>
            <span className="text-gray-300">{movie.length}</span>
            <span className="px-1 border border-gold-500 text-gold-500 rounded-sm text-[8px] uppercase">{movie.contentType}</span>
          </div>

          <div className="flex flex-wrap gap-1">
            {movie.genres.slice(0, 3).map(g => (
              <span key={g} className="text-[10px] text-gray-300">{g} {movie.genres.indexOf(g) < 2 && '•'}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieCard;
