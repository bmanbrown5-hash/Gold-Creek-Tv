
import React from 'react';

interface NavbarProps {
  isScrolled: boolean;
  onAdminClick: () => void;
  onCategorySelect: (cat: string | null) => void;
  activeCategory: string | null;
}

const Navbar: React.FC<NavbarProps> = ({ isScrolled, onAdminClick, onCategorySelect, activeCategory }) => {
  const links = ['Browse', 'Action', 'Drama', 'Comedy', 'Documentary', 'Sci-Fi'];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-[60] transition-all duration-500 px-8 sm:px-12 py-4 flex items-center justify-between ${
      isScrolled ? 'bg-dark/95 backdrop-blur-md shadow-2xl border-b border-gray-800/50' : 'bg-gradient-to-b from-black/80 to-transparent'
    }`}>
      <div className="flex items-center gap-10">
        <div 
          className="text-2xl sm:text-3xl font-serif font-bold tracking-tighter cursor-pointer select-none"
          onClick={() => onCategorySelect(null)}
        >
          <span className="text-gold-500">GOLD</span>
          <span className="text-white ml-1">CREEK TV</span>
        </div>

        <div className="hidden lg:flex items-center gap-6 text-sm font-medium">
          {links.map(link => (
            <button 
              key={link}
              onClick={() => onCategorySelect(link === 'Browse' ? 'Browse' : link)}
              className={`hover:text-gold-500 transition-colors ${activeCategory === link ? 'text-gold-500 font-bold' : 'text-gray-200'}`}
            >
              {link}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="hidden sm:flex items-center gap-4">
            <button className="text-gray-300 hover:text-gold-500 transition-colors">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
            </button>
            <button className="text-gray-300 hover:text-gold-500 transition-colors">
               <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
            </button>
        </div>
        
        <div className="flex items-center gap-3 cursor-pointer group" onClick={onAdminClick}>
          <div className="w-8 h-8 rounded bg-gold-500 flex items-center justify-center text-dark font-bold group-hover:scale-110 transition-transform">
            A
          </div>
          <span className="hidden md:block text-xs font-bold text-gold-500 opacity-0 group-hover:opacity-100 transition-opacity">ADMIN</span>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
