
import React, { useRef, useState } from 'react';
import { Movie } from '../types';
import MovieCard from './MovieCard';
import { ChevronLeft, ChevronRight } from './Icons';

interface MovieRowProps {
  title: string;
  movies: Movie[];
  onMovieClick: (movie: Movie) => void;
}

const MovieRow: React.FC<MovieRowProps> = ({ title, movies, onMovieClick }) => {
  const rowRef = useRef<HTMLDivElement>(null);
  const [showLeft, setShowLeft] = useState(false);

  if (movies.length === 0) return null;

  const handleScroll = (direction: 'left' | 'right') => {
    if (rowRef.current) {
      const { scrollLeft, clientWidth } = rowRef.current;
      const scrollTo = direction === 'left' 
        ? scrollLeft - clientWidth * 0.8
        : scrollLeft + clientWidth * 0.8;
      
      rowRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
      setShowLeft(scrollTo > 0);
    }
  };

  return (
    <div className="relative mb-8 space-y-2 group">
      <h2 className="px-8 sm:px-12 text-lg sm:text-xl font-bold text-gray-200 transition-colors hover:text-white cursor-pointer inline-flex items-center group-hover:text-gold-500">
        {title}
        <ChevronRight className="w-4 h-4 ml-2 opacity-0 group-hover:opacity-100 transition-opacity" />
      </h2>
      
      <div className="relative">
        <button 
          onClick={() => handleScroll('left')}
          className={`absolute left-0 top-0 bottom-0 z-40 bg-black/40 w-12 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/60 ${!showLeft && 'hidden'}`}
        >
          <ChevronLeft className="w-8 h-8 text-white" />
        </button>

        <div 
          ref={rowRef}
          className="flex gap-2 overflow-x-auto netflix-row px-8 sm:px-12 pb-8 pt-2"
          onScroll={(e) => setShowLeft(e.currentTarget.scrollLeft > 0)}
        >
          {movies.map(movie => (
            <MovieCard key={movie.id} movie={movie} onClick={onMovieClick} />
          ))}
        </div>

        <button 
          onClick={() => handleScroll('right')}
          className="absolute right-0 top-0 bottom-0 z-40 bg-black/40 w-12 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/60"
        >
          <ChevronRight className="w-8 h-8 text-white" />
        </button>
      </div>
    </div>
  );
};

export default MovieRow;
