
import React, { useState } from 'react';
import { CloseIcon } from './Icons';

interface PasskeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (passkey: string) => void;
  error?: string | null;
}

const PasskeyModal: React.FC<PasskeyModalProps> = ({ isOpen, onClose, onSubmit, error }) => {
  const [value, setValue] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(value);
  };

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative w-full max-w-md bg-dark-100 border border-gold-500/30 rounded-xl p-8 shadow-2xl">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-500 hover:text-white transition-colors"
        >
          <CloseIcon className="w-5 h-5" />
        </button>

        <div className="text-center space-y-4 mb-8">
          <h2 className="text-2xl font-serif font-bold text-gold-500">Admin Authentication</h2>
          <p className="text-gray-400 text-sm">Please enter your private passkey to access the Gold Creek TV dashboard.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <input 
              autoFocus
              type="password"
              placeholder="••••••••••••"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              className={`w-full bg-dark-200 border ${error ? 'border-red-500' : 'border-gray-700'} focus:border-gold-500 rounded-lg px-4 py-3 text-center text-xl tracking-widest outline-none transition-all placeholder:tracking-normal placeholder:text-gray-600`}
            />
            {error && <p className="text-red-500 text-xs text-center animate-pulse">{error}</p>}
          </div>

          <button 
            type="submit"
            className="w-full bg-gold-500 hover:bg-gold-400 text-dark font-bold py-3 rounded-lg transition-all transform active:scale-95 shadow-lg shadow-gold-500/10"
          >
            Access Dashboard
          </button>
        </form>

        <p className="mt-6 text-center text-[10px] text-gray-600 uppercase tracking-widest">
          Authorized Personnel Only
        </p>
      </div>
    </div>
  );
};

export default PasskeyModal;
