
import React from 'react';
import { Movie } from '../types';
import { CloseIcon, PlayIcon, PlusIcon } from './Icons';

interface MovieModalProps {
  movie: Movie | null;
  onClose: () => void;
}

const MovieModal: React.FC<MovieModalProps> = ({ movie, onClose }) => {
  if (!movie) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-8 bg-black/80 backdrop-blur-sm overflow-y-auto pt-16 sm:pt-20">
      <div className="relative w-full max-w-4xl bg-dark-100 rounded-xl overflow-hidden shadow-2xl animate-in fade-in zoom-in duration-300">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 bg-dark-200 rounded-full text-white hover:bg-dark-300 transition-colors"
        >
          <CloseIcon className="w-6 h-6" />
        </button>

        <div className="relative aspect-video">
          <video 
            src={movie.trailerUrl}
            autoPlay
            controls
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-dark-100 via-transparent to-transparent pointer-events-none" />
          
          <div className="absolute bottom-8 left-8 space-y-4">
            <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white drop-shadow-lg">
              {movie.title}
            </h2>
            <div className="flex items-center gap-3">
              <button className="flex items-center gap-2 bg-white text-dark px-8 py-2 rounded font-bold hover:bg-gray-200 transition-colors">
                <PlayIcon className="w-6 h-6" /> Play
              </button>
              <button className="p-2 border-2 border-gray-500 rounded-full text-white hover:border-white transition-colors">
                <PlusIcon className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>

        <div className="p-8 grid grid-cols-1 md:grid-cols-[2fr_1fr] gap-8">
          <div className="space-y-6">
            <div className="flex items-center gap-4 text-sm sm:text-base">
              <span className="text-green-500 font-bold">98% Match</span>
              <span className="text-gray-400">{movie.releaseDate.split('-')[0]}</span>
              <span className="px-2 border border-gray-500 text-gray-400 rounded-sm">{movie.ageRating}</span>
              <span className="text-gray-400">{movie.length}</span>
              <span className="px-1.5 py-0.5 bg-dark-200 border border-gold-500 text-gold-500 rounded text-xs uppercase font-bold">
                {movie.contentType}
              </span>
            </div>
            
            <p className="text-lg text-gray-200 leading-relaxed">
              {movie.description}
            </p>
          </div>

          <div className="space-y-4 text-sm">
            <div>
              <span className="text-gray-500">Cast: </span>
              <span className="text-gray-300">John Doe, Jane Smith, Alan Smithee</span>
            </div>
            <div>
              <span className="text-gray-500">Genres: </span>
              <span className="text-gray-300">{movie.genres.join(', ')}</span>
            </div>
            <div>
              <span className="text-gray-500">This title is: </span>
              <span className="text-gray-300">Cinematic, Gritty, Exciting</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieModal;
