
import { Movie, AppState } from './types';
import { INITIAL_MOVIES, INITIAL_GENRES } from './constants';

const STORAGE_KEY = 'goldcreek_tv_state';

export const getAppState = (): AppState => {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {
      console.error('Failed to parse state', e);
    }
  }
  return {
    movies: INITIAL_MOVIES,
    genres: INITIAL_GENRES,
    recommendedIds: INITIAL_MOVIES.filter(m => m.isRecommended).map(m => m.id).slice(0, 5)
  };
};

export const saveAppState = (state: AppState) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
};
